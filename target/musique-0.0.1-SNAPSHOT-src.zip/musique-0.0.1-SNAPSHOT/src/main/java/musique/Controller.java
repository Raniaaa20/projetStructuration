package musique;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextArea;
import javafx.scene.text.Text;

public class Controller {
	
	@FXML 
	Button btag;
	@FXML 
	Button balbum;
	@FXML 
	Button bartist;
	@FXML 
	Button bglob;
	@FXML 
	Button bpays;
	@FXML 
	Button bevolution;
	@FXML 
	Button bsimil;
	@FXML 
	ChoiceBox taglist;
	@FXML 
	Text tagtext;
	@FXML 
	TextArea result;
	
	@FXML 
	public void initialize() {
		
		taglist.setVisible(false);
		tagtext.setVisible(false);
		
	}
	
	
	@FXML
	public void getTag() {
	    List<String> tags = APIManager.getTagList();
	    ObservableList<String> tagItems = FXCollections.observableArrayList(tags);
	    taglist.setItems(tagItems);

	    taglist.setVisible(true);
	    tagtext.setVisible(true);

	    String selectedTag = (String) taglist.getSelectionModel().getSelectedItem();
	    if (selectedTag != null) {
	        result.setText(APIManager.getTagInfo(selectedTag));
	    } else {
	        result.setText("");
	    }
	}

	
	public void getAlbum() {
		
	}
	
	public void getArtist() {}

	public void getTrendGlob() {}
	
	public void getTrendPays() {}
	
	public void getEvolution() {}
	
	public void getSimilar() {}
}
