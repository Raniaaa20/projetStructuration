package musique;



public class Launcher {
	
	public static void main(String[] args) {
		MongoClientConnection.main(args);
	}

}